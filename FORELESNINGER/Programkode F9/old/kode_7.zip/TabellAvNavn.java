/*
 * TabellAvNavn.java  E.L. 2004-02-22
 *
 * Et lite program som oppretter en tabell av ti String-referanser.
 * Programmet g�r i l�kke og leser inn navn som legges i denne tabellen.
 * L�kka stopper n�r tabellen er full eller brukeren har skrevet inn
 * et blankt (tomt) navn.
 */

import static javax.swing.JOptionPane.*;
class TabellAvNavn {
  public static void main(String[] args) {

    String[] navnene = new String[10];
    int antNavn = 0;

/*    String navn = showInputDialog("Oppgi navn (avslutt med blank): ");
    navn = navn.trim();

    while (antNavn < navnene.length && !navn.equals("")) {
      navnene[antNavn] = navn;
      antNavn++;
      navn = showInputDialog("Oppgi navn (avslutt med blank): ");
      navn = navn.trim();
    }

     if (antNavn == navnene.length && !navn.equals("")) {
	      showMessageDialog(null, "Ikke plass til flere navn.");
    }
*/

	boolean ferdig = false;
	do{
		String navn = showInputDialog("Oppgi navn (avslutt med blank): ");
        navn = navn.trim();
        if (antNavn < navnene.length && !navn.equals("")){
			navnene[antNavn] = navn;
        	antNavn++;
        	if (antNavn== navnene.length){
				showMessageDialog(null, "Ikke plass til flere navn.");
				ferdig = true;
			}
		}
        else ferdig=true;

	} while (!ferdig && antNavn<navnene.length);

   for (int i = 0; i < antNavn; i++) System.out.println(navnene[i]);
  }
}











/*  Alternativt med do-while:

	boolean ferdig = false;
	do{
		String navn = showInputDialog("Oppgi navn (avslutt med blank): ");
        navn = navn.trim();
        if (antNavn < navnene.length && !navn.equals("")){
			navnene[antNavn] = navn;
        	antNavn++;
        	if (antNavn== navnene.length){
				showMessageDialog(null, "Ikke plass til flere navn.");
				ferdig = true;
			}
		}
        else ferdig=true;

	} while (!ferdig && antNavn<navnene.length);

*/