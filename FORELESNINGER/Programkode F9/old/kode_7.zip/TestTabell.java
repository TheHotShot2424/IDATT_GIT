
// TestTabell.java  GS 2005-11-02
// Vi bare tester litt :)

class TestTabell{
	public static void main(String[] args){
		// Lager en endimensjonal og en todimensjonal tabell av den primitive datatypen int.

		int[] endimTab = new int[2];
		int[][] todimTab = new int[2][3];



		// G�r gjennom begge tabellene vha utvidet for-l�kke og "vanlig" for-l�kke og skriver ut innholdet i tabellene
		for(int a : endimTab) System.out.println("endimtab: " + a);

		for(int[] btab : todimTab)
			for(int b : btab) System.out.println("todimtab: " + b);

		for(int i = 0; i < endimTab.length; i++) System.out.println(endimTab[i]);


		for(int i = 0; i<todimTab.length;i++){
			for(int j=0; j<todimTab[i].length; j++)
			 	System.out.println(todimTab[i][j]);
		}


		/*
		 * Oppretter en tabell av referansetypen String og skriver ut
		 * innholdet av den vha utvidet for-l�kke og "vanlig" for-l�kke
		 */

		 String[] endimString = new String[3];
		 for(String c : endimString) System.out.println("EndimString: " + c);



	}
}