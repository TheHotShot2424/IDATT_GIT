// Oppgave 1-3 side 278
/*
 * VareTest.java
 */
class Vare {
  private static final double moms = 24.0;
  private static final double momsfaktor = 1.0 + moms / 100.0;

  private String varenavn;
  private int varenr;
  private double pris; // pris pr kilo, alltid uten moms

  public Vare(String startVarenavn, int startVarenr, double startPris) {
    varenavn = startVarenavn;
    varenr = startVarenr;
    pris = startPris;
  }

  public Vare(String startVarenavn, int startVarenr) {
    varenavn = startVarenavn;
    varenr = startVarenr;
    pris = 0.0;
  }

  public double finnPrisUtenMoms(double antKilo) {
    return pris * antKilo;
  }

  public double finnPrisMedMoms(double antKilo) {
    return pris * antKilo * momsfaktor;
  }

  public void settPris(double nyPris) {
    pris = nyPris;
  }

  // Oppgave side 140 i l�reboka: Lag en toString-metode
  public String toString(){
	  return "Varenr: " + varenr + "  " + varenavn + " " + pris;
  }

}


class VareTest{
	public static void main(String[] args){
		// Oppgave 1: Hva er feil i f�lgende kodebit?
		Vare[] varene = new Vare[3];
		varene[0] = new Vare("Ost", 1);
		varene[1] = new Vare("Nugatti Max", 2);
		varene[2] = new Vare("Brunost", 3);

	    varene[0].settPris(320.50);
		varene[1].settPris(123.70);
		varene[2].settPris(120.65);


// 2: Anta at tabellen navneliste er som vist p� figur 7.13, side 275.
// I tillegg har vi variabelen etNavn:
		String etNavn = "Marit";
		String[] navneliste = {"Anne","Berit","�ge","Torkel"};

// Sett opp setninger som gj�r:
// a) setter navneliste[1] til � referere til et nytt objekt med teksten anders
		navneliste[1] = "anders";

// b) setter navneliste[3] til � referere til det samme som som etNavn ref. til
		navneliste[3] = etNavn;

// c) lagrer summen av lengden til de 4 strengene i variabelen sumLengde,
//    bruk en for-setning
		int sumLengde = 0;
		for(int i= 0; i<navneliste.length; i++){
			sumLengde += navneliste[i].length;
		}
		sumLengde = 0;
		for(String tmp: navneliste) sumLengde += tmp.length;
		System.out.println("lengde: " + sumLengde);


// d) finner antall 'r'-er i alle strengene (hint: bruk indexOf() og en
//    for-setning)
		char tegn = 'r';
		int antTegn = 0;

		System.out.println("Antall tegn: " + antTegn);

/* 3 Parameteren til main() er String[] args, dvs en tabell av strenger. Dersom
 * vi kj�rer programmet fra kommandolinjen, vil ordene vi skrever etter program-
 * navnet, havne i denne tabellen, Eksempel:
 * > java etProgram Trondheim Oslo Bergen Stavanger
 * Lag en main() metode som skriver ut alle elementene i args-tabellen, og kj�r
 * programmet som vist her. Da skal alle bynavnene skrives ut.
 */


	}
}


/*
for(int i = 0; i < navneliste.length; i++){
	int index = navneliste[i].indexOf(tegn);
	System.out.println(navneliste[i]);
	while(index >= 0){
		antTegn++;
		index = navneliste[i].indexOf(tegn, index+1);
	}
}
*/