/*
 * TabellAvFag.java  E.L. 2004-02-22
 *
 * Filen inneholder tre klasser:
 *
 * Fag: Beskriver et fag med fagkode, navn og antall studiepoeng, tilbyr finn-metoder.
 *
 * Fagkatalog: Klassen inneholder en tabell av fagobjekter. St�rrelsen p� tabellen
 * settes i konstrukt�ren. Objektene opprettes etter hvert som nye fag legges inn.
 * Klienten kan sortere fagene og hente ut en oversikt ved � bruke toString().
 * Klienten kan ogs� hente ut en referanse til hvert enkelt fagobjekt.
 *
 * TabellAvFag: Testklient som leser inn data om fagene fra brukeren.
 */

import static javax.swing.JOptionPane.*;

class Fag {
  private String fagkode;  // entydig
  private String fagnavn;
  private int antSp;  // antall studiepoeng

  public Fag(String startFagkode, String startFagnavn, int startAntStudiepoeng) {
    fagkode = startFagkode;
    fagnavn = startFagnavn;
    antSp = startAntStudiepoeng;
  }

  public String finnFagkode() {
    return fagkode;
  }

  public String finnFagnavn() {
    return fagnavn;
  }

  public int finnAntStudiepoeng() {
    return antSp;
  }

  public String toString() {
    return "Kode: " + fagkode + ", Navn: " + fagnavn + ", " + antSp + " studiepoeng.";
  }
}

/*
 * Klassen Fagkatalog tilbyr f� metoder.
 * Flere metoder, se oppgave 2 etter dette delkapitlet.
 */
class Fagkatalog {
  private Fag[] fagene;
  private int antFag;

  public Fagkatalog(int startMaksAntallFag) {
    fagene = new Fag[startMaksAntallFag];
  }

  /*
   * Registrerer nytt fag. Dersom ikke plass, returneres false.
   * Ingen kontroll av at fag med denne kode er registrert fra f�r.
   */
  public boolean registrerNyttFag(String startFagkode, String startFagnavn, int startAntStudiepoeng) {
    if (antFag < fagene.length) {
      fagene[antFag] = new Fag(startFagkode, startFagnavn, startAntStudiepoeng);
      antFag++;
      return true;
    }
    else return false;  // ikke plass i tabellen
  }

  public int finnAntallFag() {
    return antFag;
  }

  public Fag finnFag(int indeks) {
    if (indeks >= 0 && indeks < antFag) return fagene[indeks];
    else return null;
  }

  /*
   * Sorterer fag etter fagkode. Algoritme: Sortering ved utvelging.
   * Sorterer bare den delen av tabellen der vi har fornuftige data,
   * det vil si de f�rste antFag elementene.
   */
  public void sorterFag() {
    for (int start = 0; start < antFag; start++) {
      int hittilMinst = start;
      for (int i = start + 1; i < antFag; i++) {
        String denneFagkode = fagene[i].finnFagkode();
        String hittilMinstFagkode = fagene[hittilMinst].finnFagkode();
        if (denneFagkode.compareToIgnoreCase(hittilMinstFagkode) < 0) hittilMinst = i;
      }
      Fag hjelp = fagene[hittilMinst];
      fagene[hittilMinst] = fagene[start];
      fagene[start] = hjelp;
    }
  }

  /*
   * Bygger opp en resultatstreng ved � sende toString()-meldingen til hvert
   * enkelt fagobjekt. Legger inn linjeskift mellom hvert fag.
   */
  public String toString() {
    String resultat = "";
    for (int i = 0; i < antFag; i++) {
      resultat += fagene[i].toString() + "\n";
    }
    return resultat;
  }
}

class TabellAvFag {

  public static void main(String[] args) {
    Fagkatalog katalogen = new Fagkatalog(10);  // maks 10 fag

    boolean ok = true;
    /* Ingen kontroll av at showInputDialog() returnerer fornuftige data */
    String kode = showInputDialog("Fagkode (avslutt med blank): ");
    while (ok && !kode.trim().equals("")) {
      String navn = showInputDialog("Fagnavn: ");
      String spLest = showInputDialog("Antall studiepoeng: ");
      int sp = Integer.parseInt(spLest.trim());

      ok = katalogen.registrerNyttFag(kode.trim(), navn.trim(), sp);
      if (ok) {
        showMessageDialog(null, "Registrering ok");
        kode = showInputDialog("Fagkode (avslutt med blank): ");
      } else showMessageDialog(null, "Ikke plass til flere fag, avslutter.");
    }

    /* Usortert liste, pr�ver finnAntFag() og finnFag() */
    String utskrift = "";
    for (int i = 0; i < katalogen.finnAntallFag(); i++) {
      utskrift += katalogen.finnFag(i).toString() + "\n";
    }
    showMessageDialog(null, "Usortert:\n" + utskrift);
    katalogen.sorterFag();

    /* Sortert liste, pr�ver toString() */
    showMessageDialog(null, "Sortert:\n" + katalogen.toString());
  }
}

/* Eksempeldata, ferdig sortert:
Kode: LV172D, Navn: Programmering i Java, 6 studiepoeng.
Kode: LV191D, Navn: Videreg�ende programmering, 6 studiepoeng.
Kode: LV193D, Navn: Web-programmering med JSP, 6 studiepoeng.
Kode: LV195D, Navn: Objektorientert programmering i C++, 12 studiepoeng.
*/