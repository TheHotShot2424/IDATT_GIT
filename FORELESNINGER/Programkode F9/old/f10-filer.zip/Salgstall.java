/*
 * Salgstall.java   E.L. 2002-07-18
 *
 * Klassen Salgstall vedlikeholder en todimensjonal tabell med
 * salgsdata for en periode p� et gitt antall uker. Antall uker
 * og antall dager pr uke bestemmes av klienten n�r et objekt av
 * klassen lages. Tabellen opprettes i konstrukt�ren.
 * Klienten gir verdi til en dag av gangen ved � bruke metoden settSalg().
 */

class Salgstall {
  private String avdeling;
  private int[][] salg;

  public Salgstall(String startAvdeling, int antuker, int antdager) {
    avdeling = startAvdeling;
    salg = new int[antuker][antdager]; // alle verdiene lik 0
  }

  public String finnAvdeling() {
    return avdeling;
  }

  public int finnAntUker() {
    return salg.length;
  }

  public int finnAntDgPrUke() {
    if (salg.length > 0) {  // antall uker
      return salg[0].length;
    }
    return -1;   // ingen data registrert
  }

  /*
   *  Metoden registrerer salg p� en bestemt dag.
   *  Returnerer true hvis salg registrert, false hvis ugyldig dag- eller ukenr
   */
  public boolean settSalg(int ukenr, int dagnr, int nyttSalg) {
    if (gyldigeIndekser(ukenr, dagnr)) {
      salg[ukenr][dagnr] = nyttSalg;
      return true;
    } else return false;
  }

  /*
   *  Metoden finner salget en bestemt dag.
   *  Returnerer -1 hvis ugyldig dag- eller ukenr.
   */
  public int finnSalg(int ukenr, int dagnr) {
    if (gyldigeIndekser(ukenr, dagnr)) {
      return salg[ukenr][dagnr];
    } else return -1;
  }

  /*
   *  Metoden finner salget en bestemt uke.
   *  Returnerer -1 hvis ugyldig ukenr.
   */
  public int finnSalgForHelUke(int ukenr) {
    if (gyldigUkenr(ukenr)) {
      int sum = 0;
      for (int i = 0; i < finnAntDgPrUke(); i++) {
        sum += salg[ukenr][i];
      }
      return sum;
    } else return -1;
  }

  /*
   *  Metoden finner salget for en bestemt ukedag, summert over alle uker.
   *  Returnerer -1 hvis ingen data, eller ugyldig dag
   */
  public int finnSalgForUkedag(int dagnr) {
    if (gyldigDagnr(0, dagnr)) {
      int sum = 0;
      for (int i = 0; i < finnAntUker(); i++) {
        sum += salg[i][dagnr];
      }
      return sum;
    }
    return -1;
  }

  /*
   *  Metoden finner totalsalget.
   */
  public int finnTotalsalg() {
    int sum = 0;
    for (int uke = 0; uke < finnAntUker(); uke++) {
      for (int dag = 0; dag < finnAntDgPrUke(); dag++) {
        sum += salg[uke][dag];
      }
    }
    return sum;
  }

  /*
   *  Metoden finner den mest l�nnsomme ukedagen, sett over
   *  hele perioden under ett. Returnerer -1 hvis data ikke registrert
   */
  public int finnMestL�nnsommeUkedag() {
    if (finnAntUker() > 0) {
      int hittilMestL�nnsomme = 0;
      int sumMaksSalg = finnSalgForUkedag(0);
      for (int dag = 1; dag < finnAntDgPrUke(); dag++) {
        int salg = finnSalgForUkedag(dag);
        if (salg > sumMaksSalg) {
          hittilMestL�nnsomme = dag;
          sumMaksSalg = salg;
        }
      }
      return hittilMestL�nnsomme;
    }
    return -1;
  }

  /*
   * Tre private hjelpemetoder for � kontrollere gyldigheten av
   * indekser. De er ikke av interesse for klientene.
   */
  private boolean gyldigUkenr(int ukenr) {
    if (ukenr >= 0 && ukenr < finnAntUker()) return true;
    else return false;
  }

  private boolean gyldigDagnr(int ukenr, int dagnr) {
    if (finnAntUker() > 0 // minst en uke er registrert
        && dagnr >= 0 && dagnr < finnAntDgPrUke()) return true;
    else return false;
  }

  private boolean gyldigeIndekser(int ukenr, int dagnr) {
    if (gyldigUkenr(ukenr) && gyldigDagnr(ukenr, dagnr)) return true;
    else return false;
  }
}